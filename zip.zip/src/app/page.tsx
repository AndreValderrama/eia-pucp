
'use client';

import ProjectInfo from '@/components/ProjectInfo';
import AlternativeCard from '@/components/AlternativeCard';
import { Button } from '@/components/ui/button';
import { mockProject, mockAlternatives } from '@/lib/mockData';
import Link from 'next/link';
import { PlusCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import type { Project, Alternative } from '@/lib/types';
import { usePathname } from 'next/navigation';

export default function DashboardPage() {
  const [project, setProject] = useState<Project | null>(null);
  const [alternativesToRender, setAlternativesToRender] = useState<Alternative[]>([]);
  const pathname = usePathname();

  useEffect(() => {
    setProject(mockProject);
    // Re-sync with mockAlternatives when the page is navigated to or dashboard is loaded
    setAlternativesToRender([...mockAlternatives]); // Use spread to ensure a new array reference
  }, [pathname]); // Re-run effect if pathname changes (e.g., navigating to dashboard)

  if (!project) {
    return <div className="flex justify-center items-center h-screen"><p>Loading project data...</p></div>;
  }

  return (
    <div className="space-y-8">
      <ProjectInfo project={project} />

      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-headline text-2xl text-primary">Project Alternatives</h2>
          <Link href="/alternatives/create" passHref>
            <Button>
              <PlusCircle className="mr-2 h-5 w-5" /> Create New Alternative
            </Button>
          </Link>
        </div>
        {alternativesToRender.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {alternativesToRender.map((alt) => (
              <AlternativeCard key={alt.id} alternative={alt} />
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">No alternatives defined yet. Create one to get started.</p>
        )}
      </section>
    </div>
  );
}
