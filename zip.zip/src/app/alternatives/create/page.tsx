
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Layers, ChevronLeft } from 'lucide-react';
import Link from 'next/link';
import { mockAlternatives } from '@/lib/mockData';
import type { Alternative } from '@/lib/types';

const alternativeSchema = z.object({
  name: z.string().min(3, 'Alternative name must be at least 3 characters.'),
  description: z.string().optional(),
});

type AlternativeFormValues = z.infer<typeof alternativeSchema>;

export default function CreateAlternativePage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<AlternativeFormValues>({
    resolver: zodResolver(alternativeSchema),
  });

  const onSubmit = async (data: AlternativeFormValues) => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newAlternativeId = `alt-${Date.now()}`; 
    const newAlternative: Alternative = {
      id: newAlternativeId,
      name: data.name,
      description: data.description || undefined, // Ensure description is string or undefined
      effects: [], // New alternatives start with no effects
    };
    
    mockAlternatives.push(newAlternative);
    console.log('New Alternative Data:', newAlternative);
    console.log('Updated mockAlternatives:', mockAlternatives);


    toast({
      title: 'Alternative Created',
      description: `"${data.name}" has been successfully created.`,
    });
    setIsSubmitting(false);
    router.push(`/alternatives/${newAlternativeId}`); // Navigate to the new alternative's detail page
  };

  return (
    <div className="max-w-2xl mx-auto">
        <Button variant="outline" size="sm" asChild className="mb-4">
          <Link href="/alternatives">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Alternatives
          </Link>
        </Button>
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="font-headline text-2xl text-primary flex items-center gap-2">
            <Layers className="h-7 w-7" />
            Create New Alternative
          </CardTitle>
          <CardDescription>
            Define a new alternative for your project. You can add specific environmental effects later.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Alternative Name</Label>
              <Input id="name" {...register('name')} placeholder="e.g., Tunnel Bypass Route, Upgraded Technology Option" />
              {errors.name && <p className="text-sm text-destructive mt-1">{errors.name.message}</p>}
            </div>
            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea id="description" {...register('description')} placeholder="Provide a brief description of this alternative." />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? 'Creating...' : 'Create Alternative'}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
